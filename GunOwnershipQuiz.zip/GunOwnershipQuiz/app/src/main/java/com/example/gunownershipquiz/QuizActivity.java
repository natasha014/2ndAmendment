package com.example.gunownershipquiz;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.media.MediaRecorder;
import android.os.Environment;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import com.choosemuse.libmuse.MuseManagerAndroid;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;


public class QuizActivity extends AppCompatActivity {
    public static final int i = 0;

    private MuseManagerAndroid manager;
    private List<String> allQuestions;
    int qid = 0;
    TextView txtQuestion;
    Button recBtn;
    Button stopBtn;
    Button yesBtn;
    Button noBtn;
    Button butNext;
    MediaRecorder recorder;
    private static final String BASENAME="recording.3gp";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_quiz);

        manager = MuseManagerAndroid.getInstance();
        manager.setContext(this);

        checkReadPermission();

        recorder = new MediaRecorder();

        try {
            recorder.prepare();
        } catch (IOException e) {
            e.printStackTrace();
        }

        recorder.reset();
        recorder.setAudioSource(MediaRecorder.AudioSource.MIC);
        recorder.setOutputFormat(MediaRecorder.OutputFormat.THREE_GPP);
        recorder.setAudioEncoder(MediaRecorder.AudioEncoder.AMR_NB);

        File output= new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS), BASENAME);
//        recorder.setOutputFile(output.getAbsolutePath());


        //create array of all questions
        allQuestions = new ArrayList<String>();
        createList(allQuestions);

        //get text field for question
        txtQuestion = findViewById(R.id.textView);
        butNext = findViewById(R.id.button3);
        recBtn = findViewById(R.id.button4);
        stopBtn = findViewById(R.id.button5);
        setQuestionView();

        //when recording button is clicked
        recBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //start recording voice
                recorder.start();
            }
        });

        stopBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //stop recording voice
                recorder.stop();
                recorder.reset();   // You can reuse the object by going back to setAudioSource() step
                recorder.release(); // Now the object cannot be reused
            }
        });


        //when next button is clicked, goes to next question
        butNext.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(qid<14) {
                    setQuestionView();
                }
                else {
                    Intent intent = new Intent(QuizActivity.this, EndActivity.class);

                }
            }
        });

    }

    private void checkReadPermission() {
        if (ContextCompat.checkSelfPermission(this,
                Manifest.permission.RECORD_AUDIO)
                != PackageManager.PERMISSION_GRANTED) {

            ActivityCompat.requestPermissions(this,new String[]{Manifest.permission.RECORD_AUDIO}, 0);
        }
        if (ContextCompat.checkSelfPermission(this,
                Manifest.permission.WRITE_EXTERNAL_STORAGE)
                != PackageManager.PERMISSION_GRANTED) {

            ActivityCompat.requestPermissions(this,new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE}, 0);
        }
        if (ContextCompat.checkSelfPermission(this,
                Manifest.permission.READ_EXTERNAL_STORAGE)
                != PackageManager.PERMISSION_GRANTED) {

            ActivityCompat.requestPermissions(this,new String[]{Manifest.permission.READ_EXTERNAL_STORAGE}, 0);
        }

    }

    private void setQuestionView() {
        txtQuestion.setText(allQuestions.get(qid));
        qid++;
    }

    public static void createList(List<String> l) {
        //baseline questions
        l.add("Are you over 18 years old?");
        //the goal is to ask the subject pointed yes/no questions
        l.add("Are you very anxious, worried or scared about a lot of things in your life?");
        l.add("Do you feel unusually restless, agitated, frantic, or tense?");
        l.add("Do you have chronic trouble sleeping/insomnia?");
        l.add("Are you having difficulty breathing or swallowing?");
        l.add("Do you become irritable or enraged because of minor issues?");
        l.add("Do you ever take reckless or unnecessary risks?");
        l.add("Have you lost interest in activities that you used to enjoy?");
        l.add("Did you experience panic attacks in the last 6 months?");
        l.add("Were you a victim of a traumatic event in your childhood?");
        l.add("Are you scared that you will lose control, go crazy, or die?");
        l.add("Have you lost trust in humanity and yourself, and begun expecting the worst of others and of situations?");
        l.add("Do you keep thinking about death or taking your own life?");
        l.add("Have you recently experienced extreme mood swings from depression to elation without any apparent reason?");
    }
}
